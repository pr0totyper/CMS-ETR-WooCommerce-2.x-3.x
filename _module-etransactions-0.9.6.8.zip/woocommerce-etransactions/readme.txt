unzip archive in your wp-content/plugins/ directory
